from in3110_instapy import cython_filters

# Call the functions from cython_filters and test them here.

print(cython_filters.__file__)
