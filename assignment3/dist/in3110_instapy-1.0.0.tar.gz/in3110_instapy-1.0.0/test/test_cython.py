import numpy.testing as nt
from in3110_instapy.cython_filters import cython_color2gray, cython_color2sepia


def test_color2gray(image, reference_gray):
    ...


def test_color2sepia(image, reference_sepia):
    ...
