import numpy.testing as nt
from in3110_instapy.numba_filters import numba_color2gray, numba_color2sepia
import numpy as np


def test_color2gray(image, reference_gray):
    """Tests if numba_color2gray works the way it should do

    Args:
        image (any), reference_gray (any)
    Returns:
        None
    """

    reference_gray = numba_color2gray(image)

    assert isinstance(
        reference_gray, np.ndarray
    ), "numba_color2gray does not return a numpy array"

    assert (
        reference_gray.shape == image.shape
    ), "Assertion error from test_color2gray: The shapes are not equal"
    assert (
        reference_gray.dtype == np.uint8
    ), "Assertion error from test_color2gray: The gray image' dtype is supposed to be uint8"
    assert (
        reference_gray.dtype == image.dtype
    ), "Assertion error from test_color2gray: The types are indifferent"

    expected_gray_value = int(
        0.21 * image[0, 0, 0] + 0.72 * image[0, 0, 1] + 0.07 * image[0, 0, 2]
    )

    nt.assert_allclose(
        reference_gray[0, 0],
        expected_gray_value,
        err_msg="The two images are not equal",
    )


def test_color2sepia(image, reference_sepia):
    """Tests if numba_color2sepia works the way it should do

    Args:
        image (any), reference_gray (any)
    Returns:
        None
    """
    reference_sepia = numba_color2sepia(image)

    assert isinstance(
        reference_sepia, np.ndarray
    ), "numba_color2sepia does not return a numpy array"

    assert (
        reference_sepia.shape == image.shape
    ), "Assertion error from test_color2sepia: The shapes are not equal"
    assert (
        reference_sepia.dtype == np.uint8
    ), "Assertion error from test_color2sepia: The sepia image's dtype is supposed to be uint8"
    assert (
        reference_sepia.dtype == image.dtype
    ), "Assertion error from test_color2sepia: The types are indifferent"

    expected_pixel_value = [
        int(0.393 * image[0, 0, 0] + 0.769 * image[0, 0, 1] + 0.189 * image[0, 0, 2]),
        int(0.349 * image[0, 0, 0] + 0.686 * image[0, 0, 1] + 0.168 * image[0, 0, 2]),
        int(0.272 * image[0, 0, 0] + 0.534 * image[0, 0, 1] + 0.131 * image[0, 0, 2]),
    ]

    assert np.allclose(
        reference_sepia[0, 0],
        expected_pixel_value,
    ), "Assertion error from test_color2sepia: The two images are not equal"
